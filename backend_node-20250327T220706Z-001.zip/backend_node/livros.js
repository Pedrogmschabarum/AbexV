let livros = [
    {
        id : 1,
        titulo: "O Hobbit",
        autor: "J.R.R. Tolkien",
        totalPáginas: "310",
        categoria: ["Ação", "Fantasia", "Aventura", "Medieval"],
        reviews: [
            {usuario: "Pedro", nota: 5, comentario: "Muito bom!"}
        ]
    },
    {
        id: 2,
        titulo: "One Piece Cap. 1",
        autor: "Eichiro Oda",
        totalPáginas: "192",
        categoria: ["Anime", "Fantasia", "Aventura", "Pirata"],
        reviews: []
    }
];

function getLivros() {
    return livros
}

function getLivroPorId(id) {
    return livros.find(livro => livro.id === id);
}

function livroReview(idLivro) {
    const livro = getLivroPorId(idLivro);
    if (!livro) return null;
    return livro.reviews
}

function getLivroPorAutor(autor){
    return livros.filter(livro => livro.autor === autor);
}

function getLivroPorCategoria(categoria){
    return livros.filter(livro => livro.categoria.includes(categoria));
}

function adicionarReview(idLivro, usuario, nota, comentario){
    const livro = getLivroPorId(idLivro);
    if (!livro) return null;

    const novaReview = {usuario, nota, comentario};
    livro.reviews.push(novaReview)

    return novaReview;
}

function adicionarLivro (titulo, autor, totalPáginas, categoria){
    const novoId = livros.length > 0 ? livros[livros.length - 1].id + 1 : 1;

    const novoLivro = {
        id: novoId,
        titulo: titulo,
        autor: autor,
        totalPáginas: totalPáginas,
        categoria: categoria,
        reviews: [],
    };

    livros.push(novoLivro);
    return novoLivro;
}

module.exports = {getLivros, getLivroPorId, adicionarReview, livroReview, getLivroPorAutor, getLivroPorCategoria, adicionarLivro};