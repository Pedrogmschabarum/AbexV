let livros = [
    { id:  1, name: "", site: "" },
    { id:  2, name: "", site: "" },
    { id:  3, name: "", site: "" }
];

class LivrosController {

    //listagem dos registros
    index(req, res) {
        return res.json(livros)
    }

    //recupera um registro
    show(req, res) {
        const id = parseInt(req.body.id);
        const livro = livros.find(item => item.id === id);
        const status = livro ? 200 : 400;

        console.debug("GET :: /livros:/id", livros);

        return res.status(status).json(livros)
    }

    //cria um registro
    create(req, res) {
        const { name, site } = req.body; // mostro para criar um novo usuario com nome e site
        const id = livros[livros.length - 1].id + 1; //faço com que leia o tamanho da array customers e va para a ultima linha e adicione um novo id

        const newLivros = { id, name, site }; //armazeno as informações dentro da variavel newCustomer
        livros.push(newLivros); //dou um push para criar novo usuario

        return res.status(201).json(newLivros)
    }

    //atualiza um registro
    update(req, res) {
        const id = parseInt(req.params.id) //faço com que o id se transforme em um inteiro
        const { name, site } = req.body; //puxo o name e site do body

        const index = livros.findIndex(item => item.id === id) //faço com que o index seja o id acahdo do cliente
        const status = index >= 0 ? 200 : 404 //caso exista o cliente que foi pesquisado, mostra 200, caso contrario, 400

        if(index >= 0) {
            livros[index] = { id: parseInt(id), name, site } //caso ache o index e ele exista, atualizo com novas informações (id, name, site)
        }

        return res.status(status).json(livros[index]) 
    }

    //deleta um registro
    destroy(req, res) {
        const id = parseInt(req.params.id) //faço com que o id se transforme em um inteiro, e recebo um id 
        const index = livros.findIndex(item => item.id === id) //faço com que o index seja o id achado do cliente
        const status = index >= 0 ? 200 : 400 //calculo o status, caso seja achado é claro

        if(index>=0){ //se o index for achado
            livros.splice(index, 1) //faço com que exclua 
        }

        return res.status(status).json()
    }
    
}

export default new LivrosController();