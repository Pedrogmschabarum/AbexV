import app from "./app";

app.listen(6060, () => {
    console.log("Servidor rodando na porta 6060");
});
