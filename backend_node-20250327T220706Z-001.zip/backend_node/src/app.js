// Arquivo responsável por iniciar o processo, tanto de rotas quanto do Express
import express from "express"
import routes from "./routes";

// Organização por classes
class App {
    constructor() {
        this.server = express();
        this.middlewares();
        this.routes();
    }

    middlewares() {
        this.server.use(express.json()); // Corrigido aqui
    }

    routes() {
        this.server.use(routes); // Corrigido aqui
    }
}

export default new App().server;
