import { Router } from "express";
import livros from "./app/controllers/LivrosController"

const routes = new Router(); // `new Router()` não é necessário, basta `Router()`

routes.get("/livros", livros.index)
routes.get("/livros/:id", livros.show)
routes.post("/livros", livros.create)
routes.put("/livros/:id", livros.update)
routes.delete("/livros/:id", livros.destroy)

export default routes;